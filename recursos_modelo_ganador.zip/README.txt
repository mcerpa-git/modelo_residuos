========================================================================
RECURSOS DEL MODELO GANADOR - CLASIFICADOR DE RESIDUOS (TRASHNET)
========================================================================

Este paquete contiene todo lo necesario para utilizar y recrear el modelo
que logró resolver el problema de sobreajuste (Gap ~1.9%).

CONTENIDO DEL PAQUETE:
1. 'modelo_residuos_quant.tflite' -> Modelo final optimizado y cuantizado en INT8.
   Ideal para despliegue directo en dispositivos móviles y tabletas Android/iOS.
2. 'mejor_modelo_pesos.weights.h5' -> Pesos óptimos guardados durante el entrenamiento
   para el modelo Keras/TensorFlow.

INSTRUCCIONES DE RECREACIÓN:
- El modelo base utilizado fue MobileNetV2 preentrenado con ImageNet.
- Se congelaron todas las capas excepto las últimas 10 para realizar el Fine-Tuning.
- Se aplicó una capa Dense con regularización L2 (factor 5e-2) y dos capas de Dropout agresivas (0.75 y 0.65).
- El entrenamiento se realizó con Label Smoothing de 0.15 usando el optimizador Adam (LR = 1e-4).
